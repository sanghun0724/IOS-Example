//
//  UserInformation.swift
//  MyLoginService
//
//  Created by sangheon on 2020/09/21.
//

import Foundation

class UserInformation {
    
    static let shared:UserInformation = UserInformation()

    var ID:String?
    var Password:String? 
    
    
    
    
}
